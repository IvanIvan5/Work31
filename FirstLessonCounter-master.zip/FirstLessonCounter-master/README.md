# FirstLessonCounter
<p align="left">
<img src="https://user-images.githubusercontent.com/108148690/218062074-71914169-873c-4bb0-a491-4880bf1c27f5.jpeg"/>
</p>
